import React from 'react'

function Foter() {
  return (
    <div>
    <div className='container'>
       <h1 className='text-center mt-5 mb-5' style={{ color: 'darkblue', fontSize:'bold'  }}>Contact Me</h1> 
       <div className='col-12  text-center'>
        <div className='row'>
          <div className='col-sm-6 col-md-4'> <h2> Location </h2> <span><b>Madurai, Trichy</b></span></div>

          <div className='col-sm-6 col-md-4'> <h2> Phone </h2> <span> <a href='tel:+6383199787'>91+6383199787</a></span></div>

          <div className='col-sm-6 col-md-4'> <h2> Email </h2> <span> <a href='jeyasuriyaprakash007@gmail.com'>jeyasuriyaprakash007@gmail.com</a></span></div>
        </div>
       </div>
    </div>
    <br></br>
    <br></br>
    <div className='text-center bg-black ' style={{color:'white'}}>
    
   <i > 2022 @ copyright by JP </i>
   
   </div>
   <br></br>
    </div>
  )
}

export default Foter
